import xlrd
import pandas as pd

data = xlrd.open_workbook('example4.xls')
sheetnames = data.sheet_names()

##创建一个空的DataFrame
df = pd.DataFrame()

for name in sheetnames:
    sheet = pd.read_excel('example4.xls', sheet_name=name)
    df = pd.concat([df, sheet])

df.to_excel('合并.xls', index=True)