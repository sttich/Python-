import os
import xlrd
import pandas as pd

file_path = 'E:/居家办公/python培训/example5/'
files = os.listdir(file_path)

df = pd.DataFrame()
for file in files:
    data = xlrd.open_workbook(file_path+file)
    sheet_names = data.sheet_names()
    for name in sheet_names:
        sheet = pd.read_excel(file_path+file, sheet_names=name)
        df = pd.concat([df,sheet])

df.to_excel('example5_合并.xls', index=None)