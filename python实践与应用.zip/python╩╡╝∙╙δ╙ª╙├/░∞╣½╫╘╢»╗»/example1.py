import xlrd
import xlwt


xlsx = xlrd.open_workbook('7月下旬入库表.xlsx')

sheet = xlsx.sheets()[0]
# 通过sheet名查找：xlsx.sheet_by_name("7月下旬入库表")
# 通过索引查找：xlsx.sheet_by_index(0)


### 遍历excel中所有Sheet的两种方式

##方法一：
# # 获取sheet数量：xlsx.nsheets
for i in range(0, xlsx.nsheets):
     sheet = xlsx.sheet_by_index(i)
     print(sheet.name)
     print(sheet.cell_value(0, 0))


##方法二：
# # 获取所有sheet名字：xlsx.sheet_names()
#
for i in xlsx.sheet_names():
    print(i)
    table = xlsx.sheet_by_name(i)
    print(table.cell_value(0, 0))


##获取行数/列数
rows = sheet.nrows
cols = sheet.ncols


## 获取整行/整列的值
sheet = xlsx.sheet_by_index(0)
sheet.row_values(1)
sheet.col_values(1)[:10]

## 获取单元格中的值
print(sheet.cell_value(1, 2))
print(sheet.cell(0, 0).value)
print(sheet.row(0)[0].value)



# 新建工作簿
new_workbook = xlwt.Workbook()
# 新建sheet
worksheet = new_workbook.add_sheet('new_test')
# 新建单元格，并写入内容
worksheet.write(0, 0, 'test')
# 保存
new_workbook.save('example1.xls')